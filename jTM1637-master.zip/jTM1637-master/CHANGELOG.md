Changelog jTM1637

20170228
* NEW: First version with examples (Basic Overview, Clock, Raspberry Pi CPU Temperature)

