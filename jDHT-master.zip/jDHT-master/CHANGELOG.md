#### v1.01 (20170601)
* NEW: DHT22 MQTT example
* UPD: Minor changes

#### v1.00 (20170306)
* NEW: First version with B4J non-UI example
