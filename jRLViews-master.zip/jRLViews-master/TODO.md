## ToDo List for jRLViews - B4J Additional CustomViews

#### ProgressBarIndicator
NEW: Enhance the properties with: Label weight bold etc.
NEW: Set font

#### SliderX
NEW: Set axis label colour: CSS style .slider .axis .axis-label{-fx-fill: red;}

#### TimePicker
NEW: 12h and 24h mode

#### Speedbuttons
NEW: SpeedButton	Icons depending state

#### LabeledTextField
NEW: Property to place the label left, top, right

#### MaskTextField
NEW: MaskTextField		

#### MapEditor
NEW: Property to load from file, set key read only, key add + change + delete

#### SpinEdit
Spin edit with minus left, editfield in the middle, plus right. [-][Edit][+]

#### ListViewCRUD
Listview having 1 field, which operations create, read, update, delete
