#### v0.6 20180620
* NEW: SearchTextField
* UPD: Documentation

#### v0.59 20170214
* FIX: Handle events in subclasses

#### v0.58 20171011
* NEW: ButtonToolbar Property ButtonList; Method SetButtonEnanbled, AddButton, RemoveButton
* UPD: Documentation

#### v0.57 20170927
* NEW: SeparatorLine
* UPD: Documentation

#### v0.56 20170726
* NEW: ButtonToolbar FontAwesome Icon
* UPD: Documentation

#### v0.55 20170720
* NEW: ButtonToolbar Separator
* UPD: Documentation

#### v0.5 20170714
* NEW: ButtonToolbar
* UPD: Documentation

#### v0.45 20170211
* NEW: NumericTextField IsValidNumber
* FIX: Handle events in subclasses

#### v0.4 20161026
* UPD: Documentation

#### v0.35 20161025
* NEW: ListViewEdit (with editable TextFields)
* NEW: SliderX Thumb/Track settings
* NEW: All CVs default events added except ColorList (in progress)

#### v0.3 20161023
* NEW: SliderX ThumbIcon(img), ThumbColorRGB(r,g,b), TrackColorName(color), TrackColorRGB(r,g,b), StyleClasses
* NEW: ColorList SelectedIndex(Index),SelectedIndex, SelectedItem as map "ColorName":"Name", "ColorValue":"0x...", ScrollTo(Index)
* DEL: SliderX addtoparent. Use B4J designer to create multiple sliders
* FIX: All CVs * FIX reference base property.

#### v0.25 20161022
* NEW: SelectFileTextField events TextChanged, Action
* NEW: NumericTextField events TextChanged, Action
* FIX: NumericTextField set property DigitalComma

#### v0.2 20161015
* FIX: SelectFileTextField handling textinput case and cursor position
* CHG: NumericTextField validation indicator (border color) is always used whilst showing the wrong character
* NEW: NumericTextField option to set the digital comma
* UPD: Examples

#### v0.15 20161014
* NEW: LinkLabel,NumericTextField,SliderX,ColorList

#### v0.1 20161013
* NEW: First Version with Custom Control: SelectFileTextField

