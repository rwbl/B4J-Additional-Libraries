# b4j-library-jrlviews
jRLViews is an open source B4J Custom View Library (SelectFileTextField, LinkLabel, NumericTextField, SliderX, ColorList, ListViewEdit, ButtonToolbar).

The library is written in B4J (requires v5.80 or higher) making use of Inline Java (requires Java 8 update 40 or higher).

[B4J](https://www.b4x.com/b4j.html) development tool for cross platform desktop, server and IoT solutions by [Anywhere Software](https://www.b4x.com).

The library has been created for **personal use**  only. If planned for commercial use, ensure to comply to the [Oracle JDK License Agreement](https://www.oracle.com/technetwork/java/javase/terms/license/javase-license.html). 

__Library Version:__ v0.6 (Build 20180620)

## Install
Copy from folder _Library_, the files jRLViews.jar, jRLViews.xml, jRLViewsFiles.jar to the B4J Additional Library Folder.
The library jRLViews should be listed in the B4J IDE Files tab.

## jRLViewsFiles.jar
Contains the Files Folder of the Library (see Folder LibrarySource), which holds images, required to build and run a project.
For Library development: Ensure to update the file jRLViewsFiles.jar when making changes to jRLViews Library Files Folder.
Update is done by renaming jRLViewsFiles.jar to zip, update the zip file, rename back to jRLViewsFiles.jar and copy to the B4J additional library folder.

## Custom Views
* **SelectFileTextField**: TextField with a File Chooser button and option to set the case.
* **LinkLabel**: A Label with a clickable link (url).
* **NumericTextField**: TextField, with an validation indicator (border color red or transparent), for accepting numeric input only. Option to use the comma instead of the dot.
* **SliderX**: Slider with additional property settings (tick labels, tick marks, block increment, major tick unit, minor tick count, snap to ticks, value changing).
* **ColorList**: List the standard JavaFX colors in a colored customized listview. Select color name and value (0x.....).
* **ListViewEdit**: ListView with editable fields.
* **ButtonToolbar**: Toolbar with buttons (Text or Icon).
* **SeparatorLine**: Separator Line VERTICAL or HORIZONTAL.

## Files
* jRLViews.zip contains the library and sample projects.
* jRLViews.pdf manual

## Author
Robert W.B. Linn

## Licence
Copyright (C) 2017  Robert W.B. Linn
This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS for A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
You should have received a copy of the GNU General Public License along with the samples.  If not, see [GNU Licenses](http://www.gnu.org/licenses/).
