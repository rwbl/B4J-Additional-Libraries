# Changelog B4X Class xLevelIndicator

### v1.00 (Build 20211109)
* NEW: First version, published on Anywhere Software B4J Forum B4J Libraries & Classes.
