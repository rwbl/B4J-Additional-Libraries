# To-Do B4X Class xLevelIndicator

### FIX: Labels Border and Radius
If the border is 0 and the radius of the CV > 0 then top position of the labels is too high.
#### Status
Not started.

### UPD: Labels Border and Radius
Enhance error checking to ensure properties have the correct value.
#### Status
Not started.

### NEW: Property to set the Animated Duration for the Bar
The duration to display (=redraw) the bar is hardcoded (300ms).
Define a property to set the duration, with 0 to disable animation.
#### Status
Not started.
