Changelog jBH1750

20170306 (v1.01)
* UPD: Minor change

20170301 (v1.00)
* NEW: First version with B4J non-UI example.
