# b4j-library-jbh1750
jBH1750 is an open source B4J library for the BH1750 Ambient Light Sensor connected to a Raspberry Pi connected to a Raspberry Pi.

The library is written in B4J (requires v5.80 or higher) making use of Inline Java (requires Java 8 update 40 or higher).

[B4J](https://www.b4x.com/b4j.html) development tool for cross platform desktop, server and IoT solutions by [Anywhere Software](https://www.b4x.com).

The library has been created for **personal use**  only. If planned for commercial use, ensure to comply to the [Oracle JDK License Agreement](https://www.oracle.com/technetwork/java/javase/terms/license/javase-license.html). 

## Files
* jBH1750.zip contains the library and sample projects.
* jBH1750.pdf manual

__Library Version:__ 1.01 (Build 20170919)

## Install
Copy jbh1750.jar, jbh1750.xml to the B4J additional libraries folder.

## Dependecies
On jPi4J and the pi4j jar files (core, device, gpio-extension, service).
Ensure the additional library jar files are located in the B4J additional libraries folder.

## Wiring
```
BH1750 = Raspberry Pi
3.3v = 3.3v
SDA = SDA [Physical Pin#3]
SCL = SCL [Physical Pin#5]
GND = GND
```

## I2C Address
```
0x23
```

## Example B4J Non-UI Program
```
Sub Process_Globals
  'Define the BH1750 device. The I2C address used is 0x23 - check out with sudo i2cdetect
  Private bh As BH1750
  'Define the request timer and interval
  Private RequestTimer As Timer
  Private RequestInterval As Long = 2000
End Sub

Sub AppStart (Args() As String)
  ' Init the BH1750 device with device address 0x23 or 0x5C and bus number 0 (Pi 1) or 1 (Pi 2,3)
  If bh.Initialize(0x23, 1) = False Then Return
  ' Power on and set the measurement mode
  bh.PowerOnSetMode(bh.CONTINUOUS_HIGH_RES_MODE_1)
  Log("BH1750 Initialized")
  ' Get the first value
  RequestTimer_Tick
  ' Init and start the request timer
  RequestTimer.Initialize("RequestTimer", RequestInterval)
  RequestTimer.Enabled = True
  ' Do not forget to start the message loop
  StartMessageLoop
End Sub

' Handle timer requests
Sub RequestTimer_Tick
  Log($"${DateTime.Time(DateTime.Now)} ${NumberFormat(bh.LightIntensity,0,0)} lux"$)
End Sub
```

__Output__
```
11:30:56 110 lux
11:30:58 62 lux
11:31:00 290 lux
11:31:02 288 lux
11:31:04 288 lux
```

## Author
Robert W.B. Linn

## Licence
Copyright (C) 2017  Robert W.B. Linn
This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS for A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
You should have received a copy of the GNU General Public License along with the samples.  If not, see [GNU Licenses](http://www.gnu.org/licenses/).

