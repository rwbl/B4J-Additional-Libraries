v1.1 (20170302)
* UPD: Minor changes

v1.00 (20170301)
* NEW: First version with B4J non-UI example
