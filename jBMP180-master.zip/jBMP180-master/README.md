# b4j-library-jbmp180
jBMP180 is an open source B4J Library for the I2C BMP-180 Barometric Pressure-/Temperature-/Altitude-Sensor connected to a Raspberry Pi.

The library is written in B4J (requires v5.80 or higher) making use of Inline Java (requires Java 8 update 40 or higher).

[B4J](https://www.b4x.com/b4j.html) development tool for cross platform desktop, server and IoT solutions by [Anywhere Software](https://www.b4x.com).

The library has been created for **personal use**  only. If planned for commercial use, ensure to comply to the [Oracle JDK License Agreement](https://www.oracle.com/technetwork/java/javase/terms/license/javase-license.html). 

The library is wrapped from [this](http://www.hirt.se/) BMP-180 Pressure Sensor project [many thanks to the author].

__Library Version:__ 1.1

## Files
* jBMP180.zip contains the library and sample projects.
* jBMP180.pdf manual

## Install
Copy jbmp180.jar,xml and bmp.jar to the B4J additional libraries folder.

## Dependencies
On jPi4J and the pi4j jar files (core, device, gpio-extension, service) - ensure these are located in the B4J additional libraries folder.

## Wiring
```
BMP-180 = Raspberry Pi
3.3v = 3.3v
SDA = SDA (Physical Pin#3)
SCL = SCL (Physical Pin#5)
GND = GND
```

## Example B4J Non-UI Program
```
Sub Process_Globals
   'Define the BMP 180 device with default I2C address 0x77
   'Check out the I2C address on the Raspberry Pi with command: sudo i2cdetect
   Private bmp As BMP180
   'Define the request timer and interval 5 secs
   Private RequestTimer As Timer
   Private RequestInterval As Long = 5000
End Sub

Sub AppStart (Args() As String)
   bmp.Initialize(1)  'use standard operating mode
   RequestTimer.Initialize("RequestTimer", RequestInterval)
   RequestTimer.Enabled = True
   StartMessageLoop
End Sub

Sub RequestTimer_Tick
   Log($"${DateTime.Time(DateTime.Now)}"$)
   Log($"T=${NumberFormat(bmp.ReadTemperature,0,2)}"$)
   Log($"P=${NumberFormat(bmp.ReadPressure / 100,0,1)}"$)
   Log($"A=${NumberFormat(bmp.ReadAltitude,0,1)}"$)
End Sub
Output
12:52:57
T=18.3
P=1,001.5
A=99.4
12:53:02
T=18.3
P=1,001.4
A=99
```

## Author
Robert W.B. Linn

## Licence
Copyright (C) 2017  Robert W.B. Linn
This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS for A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
You should have received a copy of the GNU General Public License along with the samples.  If not, see [GNU Licenses](http://www.gnu.org/licenses/).



